# 6) en el apartado6.R solapa el jittering y la estimación de densidad


ggplot(faithful, aes(x=eruptions, y=waiting)) +
  geom_point(aes(colour="waiting",alpha = 0.2, position="jitter")) +
  geom_density_2d()
 