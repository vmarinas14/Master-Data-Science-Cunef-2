# 5) en apartado5.R evita el overplotting usando jittering


ggplot(faithful, aes(x=eruptions, y=waiting)) +
  geom_point(aes(colour="waiting",alpha = 0.2, position="jitter"))
