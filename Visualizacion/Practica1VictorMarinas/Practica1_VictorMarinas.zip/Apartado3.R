#  3) en un fichero llamado apartado3.R haz un scatterplot 
 # de waiting (eje Y) con eruptions (eje X)

library(ggplot2)


faithful


ggplot(faithful, aes(x= eruptions, y= waiting)) +
  geom_point(aes(color=eruptions)) + geom_point(aes(color= waiting))
